from PIL import Image 

img = Image.open('bateau.jpg')

colonne, ligne = img.size

imgFinale = Image.new(img.mode, img.size)

imgSecret = Image.open('MessageSecret.jpg')

for i in range (.....):
    for j in range (......):
        (rouge1, vert1, bleu1) = img.getpixel((i,j))
        nivGris = imgSecret.getpixel((i,j))
        rouge = (19*rouge1 + nivGris)//20
        vert = (19*vert1 + nivGris)//20
        bleu = (19*bleu1 + nivGris)//20
        
        imgFinale.putpixel((i,j), (....., ....., ....))
imgFinale.save("ATransmettre.jpg")  
        

