from PIL import Image 

img = Image.open('bateau.jpg')
imgSecret = Image.open('ATransmettre.jpg')

colonne, ligne = img.size

imgFinale = Image.new(img.mode, img.size)


for i in range (................):
    for j in range (..........):
        (rouge1, vert1, bleu1) = img.getpixel((i,j))
        (rouge2, vert2, bleu2)  = imgSecret.getpixel((i,j))
        rouge = (............)
        vert = (.............)
        bleu = (.............)
        
        imgFinale.putpixel((i,j), (....., ......, .....))
imgFinale.save("MessageSecret.jpg")  
        

